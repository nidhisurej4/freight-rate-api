CREATE TABLE contract_rate (
    id                  BIGSERIAL PRIMARY KEY,
    customer_code       VARCHAR(32)    NOT NULL,
    origin              CHAR(5)        NOT NULL,
    destination         CHAR(5)        NOT NULL,
    container_type      VARCHAR(10)    NOT NULL,
    base_rate           NUMERIC(12, 2) NOT NULL CHECK (base_rate > 0),
    currency            CHAR(3)        NOT NULL,
    valid_from          DATE           NOT NULL,
    valid_to            DATE           NOT NULL,
    status              VARCHAR(12)    NOT NULL,
    version             INT            NOT NULL DEFAULT 1,
    previous_version_id BIGINT REFERENCES contract_rate (id),
    created_at          TIMESTAMPTZ    NOT NULL DEFAULT now(),
    CHECK (valid_to >= valid_from)
);

CREATE INDEX idx_rate_lookup
    ON contract_rate (customer_code, origin, destination, container_type, status);
