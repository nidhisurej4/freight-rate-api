package com.nidhisk.freightrate.service;

import com.nidhisk.freightrate.dto.*;
import com.nidhisk.freightrate.exception.BusinessRuleException;
import com.nidhisk.freightrate.exception.NotFoundException;
import com.nidhisk.freightrate.model.ContractRate;
import com.nidhisk.freightrate.model.RateStatus;
import com.nidhisk.freightrate.repository.ContractRateRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;

@Service
public class RateService {

    private final ContractRateRepository repo;

    public RateService(ContractRateRepository repo) {
        this.repo = repo;
    }

    public ContractRate create(RateRequest req) {
        validateDates(req.validFrom(), req.validTo());
        ContractRate r = new ContractRate();
        r.setCustomerCode(req.customerCode());
        r.setOrigin(req.origin().toUpperCase());
        r.setDestination(req.destination().toUpperCase());
        r.setContainerType(req.containerType().toUpperCase());
        r.setBaseRate(req.baseRate());
        r.setCurrency(req.currency().toUpperCase());
        r.setValidFrom(req.validFrom());
        r.setValidTo(req.validTo());
        return repo.save(r);
    }

    public ContractRate get(Long id) {
        return repo.findById(id).orElseThrow(() -> new NotFoundException("Rate " + id + " not found"));
    }

    public List<ContractRate> filedRatesFor(String customerCode) {
        return repo.findByCustomerCodeAndStatus(customerCode, RateStatus.FILED);
    }

    /** Filing makes a DRAFT rate usable for quoting. */
    @Transactional
    public ContractRate file(Long id) {
        ContractRate r = get(id);
        if (r.getStatus() != RateStatus.DRAFT) {
            throw new BusinessRuleException("Only DRAFT rates can be filed (current: " + r.getStatus() + ")");
        }
        r.setStatus(RateStatus.FILED);
        return repo.save(r);
    }

    /**
     * Amending never edits a filed rate in place. It supersedes the current
     * version and files a new one, so the full history stays auditable.
     */
    @Transactional
    public ContractRate amend(Long id, AmendmentRequest req) {
        ContractRate current = get(id);
        if (current.getStatus() != RateStatus.FILED) {
            throw new BusinessRuleException("Only FILED rates can be amended");
        }
        ContractRate next = new ContractRate();
        next.setCustomerCode(current.getCustomerCode());
        next.setOrigin(current.getOrigin());
        next.setDestination(current.getDestination());
        next.setContainerType(current.getContainerType());
        next.setCurrency(current.getCurrency());
        next.setBaseRate(req.baseRate() != null ? req.baseRate() : current.getBaseRate());
        next.setValidFrom(req.validFrom() != null ? req.validFrom() : current.getValidFrom());
        next.setValidTo(req.validTo() != null ? req.validTo() : current.getValidTo());
        validateDates(next.getValidFrom(), next.getValidTo());
        next.setVersion(current.getVersion() + 1);
        next.setPreviousVersionId(current.getId());
        next.setStatus(RateStatus.FILED);

        current.setStatus(RateStatus.SUPERSEDED);
        repo.save(current);
        return repo.save(next);
    }

    public QuoteResponse quote(QuoteRequest req) {
        ContractRate r = repo.findApplicableRate(
                        req.customerCode(), req.origin().toUpperCase(), req.destination().toUpperCase(),
                        req.containerType().toUpperCase(), req.shipDate())
                .orElseThrow(() -> new NotFoundException("No filed rate covers this lane and date"));
        BigDecimal total = r.getBaseRate().multiply(BigDecimal.valueOf(req.quantity()));
        return new QuoteResponse(r.getId(), r.getVersion(), r.getBaseRate(), req.quantity(), total, r.getCurrency());
    }

    private void validateDates(LocalDate from, LocalDate to) {
        if (to.isBefore(from)) {
            throw new BusinessRuleException("validTo must be on or after validFrom");
        }
    }
}
