package com.nidhisk.freightrate.controller;

import com.nidhisk.freightrate.dto.*;
import com.nidhisk.freightrate.model.ContractRate;
import com.nidhisk.freightrate.service.RateService;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/v1")
public class RateController {

    private final RateService service;

    public RateController(RateService service) {
        this.service = service;
    }

    @PostMapping("/rates")
    @ResponseStatus(HttpStatus.CREATED)
    public ContractRate create(@Valid @RequestBody RateRequest req) {
        return service.create(req);
    }

    @GetMapping("/rates/{id}")
    public ContractRate get(@PathVariable Long id) {
        return service.get(id);
    }

    @GetMapping("/customers/{customerCode}/rates")
    public List<ContractRate> filedRates(@PathVariable String customerCode) {
        return service.filedRatesFor(customerCode);
    }

    @PostMapping("/rates/{id}/file")
    public ContractRate file(@PathVariable Long id) {
        return service.file(id);
    }

    @PostMapping("/rates/{id}/amendments")
    @ResponseStatus(HttpStatus.CREATED)
    public ContractRate amend(@PathVariable Long id, @Valid @RequestBody AmendmentRequest req) {
        return service.amend(id, req);
    }

    @PostMapping("/quotes")
    public QuoteResponse quote(@Valid @RequestBody QuoteRequest req) {
        return service.quote(req);
    }
}
