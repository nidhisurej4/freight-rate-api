package com.nidhisk.freightrate.dto;

import java.math.BigDecimal;

public record QuoteResponse(
        Long rateId,
        int rateVersion,
        BigDecimal unitRate,
        int quantity,
        BigDecimal total,
        String currency) {}
