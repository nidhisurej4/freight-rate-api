package com.nidhisk.freightrate.dto;

import jakarta.validation.constraints.*;
import java.time.LocalDate;

public record QuoteRequest(
        @NotBlank String customerCode,
        @NotBlank String origin,
        @NotBlank String destination,
        @NotBlank String containerType,
        @Min(1) int quantity,
        @NotNull LocalDate shipDate) {}
