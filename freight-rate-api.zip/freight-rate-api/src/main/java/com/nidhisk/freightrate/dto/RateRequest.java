package com.nidhisk.freightrate.dto;

import jakarta.validation.constraints.*;
import java.math.BigDecimal;
import java.time.LocalDate;

public record RateRequest(
        @NotBlank String customerCode,
        @NotBlank @Size(min = 5, max = 5) String origin,
        @NotBlank @Size(min = 5, max = 5) String destination,
        @NotBlank String containerType,
        @NotNull @DecimalMin("0.01") BigDecimal baseRate,
        @NotBlank @Size(min = 3, max = 3) String currency,
        @NotNull LocalDate validFrom,
        @NotNull LocalDate validTo) {}
