package com.nidhisk.freightrate.repository;

import com.nidhisk.freightrate.model.ContractRate;
import com.nidhisk.freightrate.model.RateStatus;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

public interface ContractRateRepository extends JpaRepository<ContractRate, Long> {

    List<ContractRate> findByCustomerCodeAndStatus(String customerCode, RateStatus status);

    @Query("""
           select r from ContractRate r
           where r.customerCode = :customer and r.origin = :origin
             and r.destination = :destination and r.containerType = :containerType
             and r.status = com.nidhisk.freightrate.model.RateStatus.FILED
             and :date between r.validFrom and r.validTo
           """)
    Optional<ContractRate> findApplicableRate(String customer, String origin, String destination,
                                              String containerType, LocalDate date);
}
