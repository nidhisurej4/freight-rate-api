package com.nidhisk.freightrate.dto;

import jakarta.validation.constraints.DecimalMin;
import java.math.BigDecimal;
import java.time.LocalDate;

/** Any null field keeps the value from the current version. */
public record AmendmentRequest(
        @DecimalMin("0.01") BigDecimal baseRate,
        LocalDate validFrom,
        LocalDate validTo) {}
