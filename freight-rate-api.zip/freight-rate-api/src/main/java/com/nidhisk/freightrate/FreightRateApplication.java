package com.nidhisk.freightrate;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FreightRateApplication {
    public static void main(String[] args) {
        SpringApplication.run(FreightRateApplication.class, args);
    }
}
