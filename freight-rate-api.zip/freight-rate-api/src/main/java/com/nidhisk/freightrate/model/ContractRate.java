package com.nidhisk.freightrate.model;

import jakarta.persistence.*;
import java.math.BigDecimal;
import java.time.Instant;
import java.time.LocalDate;

/**
 * A contracted rate for moving one container type between two locations
 * for one customer, valid within a date window.
 */
@Entity
@Table(name = "contract_rate")
public class ContractRate {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false) private String customerCode;
    @Column(nullable = false) private String origin;        // UN/LOCODE, e.g. INBLR
    @Column(nullable = false) private String destination;   // UN/LOCODE, e.g. NLRTM
    @Column(nullable = false) private String containerType; // 20DRY, 40DRY, 40HC, 40REEF
    @Column(nullable = false) private BigDecimal baseRate;
    @Column(nullable = false) private String currency;
    @Column(nullable = false) private LocalDate validFrom;
    @Column(nullable = false) private LocalDate validTo;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private RateStatus status = RateStatus.DRAFT;

    @Column(nullable = false) private int version = 1;
    private Long previousVersionId;
    private Instant createdAt = Instant.now();

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }
    public String getCustomerCode() { return customerCode; }
    public void setCustomerCode(String v) { this.customerCode = v; }
    public String getOrigin() { return origin; }
    public void setOrigin(String v) { this.origin = v; }
    public String getDestination() { return destination; }
    public void setDestination(String v) { this.destination = v; }
    public String getContainerType() { return containerType; }
    public void setContainerType(String v) { this.containerType = v; }
    public BigDecimal getBaseRate() { return baseRate; }
    public void setBaseRate(BigDecimal v) { this.baseRate = v; }
    public String getCurrency() { return currency; }
    public void setCurrency(String v) { this.currency = v; }
    public LocalDate getValidFrom() { return validFrom; }
    public void setValidFrom(LocalDate v) { this.validFrom = v; }
    public LocalDate getValidTo() { return validTo; }
    public void setValidTo(LocalDate v) { this.validTo = v; }
    public RateStatus getStatus() { return status; }
    public void setStatus(RateStatus v) { this.status = v; }
    public int getVersion() { return version; }
    public void setVersion(int v) { this.version = v; }
    public Long getPreviousVersionId() { return previousVersionId; }
    public void setPreviousVersionId(Long v) { this.previousVersionId = v; }
    public Instant getCreatedAt() { return createdAt; }
}
