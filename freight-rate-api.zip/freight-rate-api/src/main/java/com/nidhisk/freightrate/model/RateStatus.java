package com.nidhisk.freightrate.model;

public enum RateStatus { DRAFT, FILED, SUPERSEDED }
