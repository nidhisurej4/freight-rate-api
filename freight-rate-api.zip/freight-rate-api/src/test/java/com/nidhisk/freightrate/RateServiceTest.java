package com.nidhisk.freightrate;

import com.nidhisk.freightrate.dto.*;
import com.nidhisk.freightrate.exception.BusinessRuleException;
import com.nidhisk.freightrate.model.ContractRate;
import com.nidhisk.freightrate.model.RateStatus;
import com.nidhisk.freightrate.repository.ContractRateRepository;
import com.nidhisk.freightrate.service.RateService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.Optional;

import static org.assertj.core.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

class RateServiceTest {

    private ContractRateRepository repo;
    private RateService service;

    @BeforeEach
    void setUp() {
        repo = mock(ContractRateRepository.class);
        when(repo.save(any())).thenAnswer(inv -> inv.getArgument(0));
        service = new RateService(repo);
    }

    private ContractRate filedRate() {
        ContractRate r = new ContractRate();
        r.setId(1L);
        r.setCustomerCode("ACME");
        r.setOrigin("INBLR");
        r.setDestination("NLRTM");
        r.setContainerType("40HC");
        r.setBaseRate(new BigDecimal("1800.00"));
        r.setCurrency("USD");
        r.setValidFrom(LocalDate.of(2026, 1, 1));
        r.setValidTo(LocalDate.of(2026, 12, 31));
        r.setStatus(RateStatus.FILED);
        return r;
    }

    @Test
    void createRejectsInvertedDates() {
        RateRequest req = new RateRequest("ACME", "INBLR", "NLRTM", "40HC",
                new BigDecimal("1500"), "USD", LocalDate.of(2026, 6, 1), LocalDate.of(2026, 1, 1));
        assertThatThrownBy(() -> service.create(req)).isInstanceOf(BusinessRuleException.class);
    }

    @Test
    void amendSupersedesOldVersionAndBumpsVersion() {
        ContractRate current = filedRate();
        when(repo.findById(1L)).thenReturn(Optional.of(current));

        ContractRate next = service.amend(1L, new AmendmentRequest(new BigDecimal("1950.00"), null, null));

        assertThat(current.getStatus()).isEqualTo(RateStatus.SUPERSEDED);
        assertThat(next.getVersion()).isEqualTo(2);
        assertThat(next.getPreviousVersionId()).isEqualTo(1L);
        assertThat(next.getBaseRate()).isEqualByComparingTo("1950.00");
        assertThat(next.getValidTo()).isEqualTo(current.getValidTo());
    }

    @Test
    void cannotFileAnAlreadyFiledRate() {
        when(repo.findById(1L)).thenReturn(Optional.of(filedRate()));
        assertThatThrownBy(() -> service.file(1L)).isInstanceOf(BusinessRuleException.class);
    }

    @Test
    void quoteMultipliesRateByQuantity() {
        when(repo.findApplicableRate(any(), any(), any(), any(), any())).thenReturn(Optional.of(filedRate()));

        QuoteResponse q = service.quote(new QuoteRequest("ACME", "inblr", "nlrtm", "40hc", 3, LocalDate.of(2026, 5, 10)));

        assertThat(q.total()).isEqualByComparingTo("5400.00");
        assertThat(q.currency()).isEqualTo("USD");
    }
}
